<footer class="main-footer">
    @yield('footer')
</footer>