<?php

return [

    /*
    |--------------------------------------------------------------------------
    | IFrame Mode Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used by the AdminLTE IFrame mode blade
    | layout. You are free to modify these language lines according to your
    | application's requirements.
    |
    */

    'btn_close' => 'Zavrieť',
    'btn_close_active' => 'Zavrieť aktívne',
    'btn_close_all' => 'Zavrieť všetky',
    'btn_close_all_other' => 'Zavrieť všetky ostatné',
    'tab_empty' => 'Nie je vybraný tab!',
    'tab_home' => 'Domov',
    'tab_loading' => 'Tab sa načítava',

];
