<?php

return [

    'main_navigation'               => 'HAUPTMENÜ',
    'blog'                          => 'Blog',
    'pages'                         => 'Seiten',
    'account_settings'              => 'KONTOEINSTELLUNGEN',
    'profile'                       => 'Profil',
    'change_password'               => 'Passwort ändern',
    'multilevel'                    => 'Multi Level',
    'level_one'                     => 'Level 1',
    'level_two'                     => 'Level 2',
    'level_three'                   => 'Level 3',
    'labels'                        => 'Beschriftungen',
    'important'                     => 'Wichtig',
    'warning'                       => 'Warnung',
    'information'                   => 'Information',
];
